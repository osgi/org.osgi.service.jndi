/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/


package org.osgi.test.cases.jndi.secure.provider;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.spi.InitialContextFactory;

/** 
 * @author $Id: 8f671868d6d2ee0ab187ea59c12cb9ef59aa55c3 $
 */
public class CTInitialContextFactoryBuilder implements javax.naming.spi.InitialContextFactoryBuilder {

	@Override
	public InitialContextFactory createInitialContextFactory(
			Hashtable< ? , ? > env) throws NamingException {
		String contextFactory =  (String) env.get(Context.INITIAL_CONTEXT_FACTORY);
		if (contextFactory != null) {
			if (contextFactory.equals(CTInitialContextFactory.class.getName())) {
				return new CTInitialContextFactory();
			} else {
				return null;
			}
		} else {
			return new CTInitialContextFactory();
		}
	}

}
