/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/


package org.osgi.test.cases.jndi.dirObjectFactory1;

import java.util.Dictionary;
import java.util.Hashtable;

import javax.naming.spi.DirObjectFactory;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.osgi.test.cases.jndi.provider.CTDirObjectFactory;

/**
 * @author $Id: 45e9f2833a13194c7543db98ea65cf66bcb6103b $
 */
public class DirObjectFactory1Activator implements BundleActivator {

	private ServiceRegistration< ? > sr;
	
	@Override
	public void start(BundleContext context) throws Exception {
		System.out.println("Starting: " + context.getBundle().getLocation());
		Dictionary<String,Object> props = new Hashtable<>();
		String[] interfaces = {CTDirObjectFactory.class.getName(), DirObjectFactory.class.getName()};
		
		CTDirObjectFactory of = new CTDirObjectFactory();
		sr = context.registerService(interfaces, of, props);		
		
	}

	@Override
	public void stop(BundleContext context) throws Exception {
		System.out.println("Stopping: " + context.getBundle().getLocation());
		sr.unregister();
	}

}
