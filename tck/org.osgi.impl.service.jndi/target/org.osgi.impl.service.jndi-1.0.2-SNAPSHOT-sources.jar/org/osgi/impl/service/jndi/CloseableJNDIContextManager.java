/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/


package org.osgi.impl.service.jndi;

import org.osgi.service.jndi.JNDIContextManager;

/**
 * Closeable extension of the JNDIContextManager interface, to be 
 * used internally by the JNDI implementation.    
 *
 * 
 * @author $Id: d83f37f34c9df546c56bd44c0e531b30dae48baa $
 */
interface CloseableJNDIContextManager extends JNDIContextManager {
	public void close();
}
